def upcoming_birthdays(people_list, days):
    # TODO: write code that finds all upcoming birthdays in the next 90 days
    # 90 is passed in as a parameter from menus.py
    # Template:
    # PERSON turns AGE in X days on MONTH DAY
    # PERSON turns AGE in X days on MONTH DAY
    print("Upcoming Birthdays function")
    print(people_list)
    pass


def display_age(person):
    # TODO: write code to display the age of person
    # Template:
    # PERSON is X years, X months, and X days old

    print(person)
    pass


def display_age_difference(people):
    # TODO: write the code to display the age difference between people
    # Template:
    # PERSON is older
    # PERSON and PERSON's age difference is: X years, X months, and X days

    print(people)
    pass
